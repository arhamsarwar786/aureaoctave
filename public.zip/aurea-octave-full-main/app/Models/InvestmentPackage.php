<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InvestmentPackage extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'code',
        'expense_ratio',
        'sec_yield',
        'ytd',
        'one_year',
        'fund_price'
    ];
}