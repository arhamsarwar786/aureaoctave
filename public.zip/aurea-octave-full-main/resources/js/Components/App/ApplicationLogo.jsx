// import LOGO from "@/assets/img/auth-logo.png";
export default function ApplicationLogo(props) {
    // return <img {...props} src={LOGO} />;
}
