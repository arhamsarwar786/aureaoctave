import { navLinks } from "@/utils/constants";
import { Link } from "@inertiajs/react";
import React from "react";

const Footer = () => {
    const socials = [
        {
            title: "Instagram",
            link: "",
            img: "/assets/img/socials/instagram.png",
        },
        { title: "X", link: "", img: "/assets/img/socials/x.png" },
        { title: "Github", link: "", img: "/assets/img/socials/github.png" },
        {
            title: "Behance",
            link: "",
            img: "/assets/img/socials/behance.png",
        },
    ];
    return (
        <footer className="bg-[#f5f5f5] text-secondary pt-12 pb-8 mt-20">
            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 md:grid-cols-5 gap-y-10">
                    <div className="col-span-2 space-y-5">
                        <p className="text-sm">
                            Aurea Octave is one of the world’s leading providers
                            of investment, advisory and risk management
                            solutions. We are a fiduciary to our clients. We’re
                            investing for the future on behalf of our clients,
                            inspiring our employees, and supporting our local
                            communities.
                        </p>
                    </div>
                    <div className="hidden md:block"></div>
                    <div className="col-span-2 md:col-span-1 flex flex-col gap-3 md:gap-5 text-sm">
                        {navLinks.map((link, index) => {
                            return (
                                <Link
                                    key={index}
                                    href={route(link.routeName)}
                                    className="hover:text-primary"
                                >
                                    {link.label}
                                </Link>
                            );
                        })}
                    </div>
                    <div className="relative space-y-5">
                        <h3 className="text-lg font-semibold">Follow Us</h3>
                        <div className="flex gap-2">
                            {socials.map((social, index) => (
                                <Link
                                    href={social.link}
                                    key={index}
                                    className="hover:text-primary"
                                >
                                    <img
                                        src={social.img}
                                        alt={social.title}
                                        className="size-10 object-cover"
                                    />
                                </Link>
                            ))}
                        </div>
                    </div>
                </div>
                <div className="lg:text-center pt-10">
                    <p className="">
                        &copy; {new Date().getFullYear()}{" "}
                        <span className="font-bold text-primary">
                            Aurea Octave
                        </span>
                        . All Rights Reserved.
                    </p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
