import FinancialFreedom from "@/Components/Partials/FinancialFreedom";
import GoodCompany from "@/Components/Partials/GoodCompany";
import WhatSetUsApart from "@/Components/Partials/WhatSetUsApart";
import WhatWeDo from "@/Components/Partials/WhatWeDo";
import GuestLayout from "@/Layouts/GuestLayout";
import { Head, Link } from "@inertiajs/react";

export default function Home() {
    const services = [
        {
            title: "Cryptocurrency",
            description:
                "We leverage AI-driven analytics to track market trends, assess volatility, and uncover opportunities in the fast-evolving world of cryptocurrency. Paired with our human expertise in regulatory compliance and strategic planning, we help you navigate the complexities of digital assets with confidence and precision, ensuring secure and profitable investments.",
            img: "/assets/img/xrp.png",
        },
        {
            title: "ETFs",
            description:
                "We analyze vast market data to identify high-performing ETFs and optimize portfolio allocations using ai. Combined with the insights of our seasoned advisors, we craft personalized strategies that align with your financial objectives, balancing innovation with a deep understanding of global markets to maximize your returns.",
            img: "/assets/img/chart.png",
        },
        {
            title: "Mergers & Acquisitions (M&A)",
            description:
                "We integrate AI’s predictive capabilities and advanced analytics with our team’s extensive experience to deliver transformative M&A solutions. From identifying ideal acquisition targets to negotiating and closing deals, our hybrid approach ensures efficiency, precision, and strategic growth tailored to your business goals",
            img: "/assets/img/handshake.png",
        },
    ];
    return (
        <GuestLayout title="Home">
            {/* Hero Section */}
            <section
                className="relative text-white min-h-[500px] h-full lg:min-h-[800px]"
                style={{
                    backgroundImage: "url('/assets/img/hero.png')",
                    backgroundPosition: "center right",
                    backgroundSize: "cover",
                    backgroundRepeat: "no-repeat",
                    position: "relative",
                }}
            >
                <div className="absolute inset-0 bg-secondary opacity-50"></div>
                <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 bg-secondary text-white">
                    <div className="absolute bottom-0 mb-20">
                        <div className="grid md:grid-cols-2 items-center">
                            <div className="relative">
                                <div className="relative space-y-5">
                                    <p className="text-sm font-semibold text-white">
                                        Your Trusted Investment Advisors
                                    </p>

                                    <h1 className="text-xl lg:text-3xl font-bold">
                                        Future Of Investing
                                    </h1>

                                    <p className="relative pl-2 text-sm before:absolute before:top-0 before:left-0 before:bottom-0 before:w-[3px] before:h-full before:rounded-full before:bg-primary">
                                        At Aurea Octave, we combine cutting-edge
                                        artificial intelligence with deep
                                        financial expertise to revolutionize how
                                        investments are managed. Our Ai-driven
                                        tools empower investors by delivering
                                        faster insights, reducing risks and
                                        uncovering opportunities that
                                        traditional methods might miss.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Services Section */}
            <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
                <div className="grid gap-y-10 gap-x-40 md:grid-cols-3">
                    {services.map((service, index) => (
                        <div key={index} className="relative space-y-1">
                            <img src={service.img} alt={service.title} />
                            <h3 className="text-lg font-semibold mb-2">
                                {service.title}
                            </h3>
                            <p className="text-sm">{service.description}</p>
                        </div>
                    ))}
                </div>
            </section>

            <WhatSetUsApart />

            <GoodCompany />

            <WhatWeDo />

            <FinancialFreedom />
        </GuestLayout>
    );
}
